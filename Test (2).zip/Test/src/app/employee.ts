export class Employee {
    id: number;
    firstName: string;
    salary: number;
    age: number;
    photo:File;
    active: boolean;
  }
  